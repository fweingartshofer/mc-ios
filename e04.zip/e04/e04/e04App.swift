//
//  e04App.swift
//  e04
//
//  Created by Florian Weingartshofer on 12.01.23.
//

import SwiftUI

@main
struct e04App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
